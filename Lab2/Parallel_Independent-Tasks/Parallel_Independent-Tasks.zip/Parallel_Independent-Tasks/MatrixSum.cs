﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Parallel_Independent_Tasks
{
    public class MatrixSum
    {
        private Matrix _first;
        private Matrix _second;
        private Matrix _result;
        int _nrThreads;

        public MatrixSum(Matrix f, Matrix s, int nr)
        {
            _first = f;
            _second = f;
            _result = new Matrix();
            _nrThreads = nr;
        }

        public Matrix First { get => _first; }
        public Matrix Second { get => _second; }
        public Matrix Result { get => _result; }
        public int NrThreads { get => _nrThreads; }

        public List<int> DivideMatrix()
        {
            List<int> _threadElementNr = new List<int>();
            var _matrixCount = First.Column * First.Row;
            var _whole = _matrixCount / NrThreads;
            var _left = _matrixCount % NrThreads;

            for (int i = 0; i < NrThreads; i++)
            {
                _threadElementNr.Add(_whole);
                if (_left > 0)
                {
                    _threadElementNr[i]+=1;
                    _left--;
                }
            }
            return _threadElementNr;
        }

        public Dictionary<int, Dictionary<int, int>> ThreadElements(Matrix m)
        {
            List<int> _nrElementsForThreads = DivideMatrix();
            Dictionary<int, Dictionary<int, int>> _matrixDividedInThreads = new Dictionary<int, Dictionary<int, int>>();
            int index = 0;
            for(int i=0; i<_nrElementsForThreads.Count; i++) //2 threads
            {
                var _nrElements = _nrElementsForThreads[i]; //nr of elements in thread
                Dictionary<int,int> _threadElements = m.GetElementsBetweenIndexes(index, _nrElements+index);
                _matrixDividedInThreads.Add(i, _threadElements);
                index = _nrElements;
            }
            return _matrixDividedInThreads;
        }

        public void AddMatrices(Dictionary<int,int> _firstThreadElements, Dictionary<int, int> _secondThreadElements)
        {
            foreach (int pos in _firstThreadElements.Keys)
                _result.ListElements.Insert(pos, _firstThreadElements[pos] + _secondThreadElements[pos]);
        }
    }
}
