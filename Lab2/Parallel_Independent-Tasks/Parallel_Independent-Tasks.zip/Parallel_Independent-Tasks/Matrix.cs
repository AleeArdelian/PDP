﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Parallel_Independent_Tasks
{
    public class Matrix
    {
        private int _row;
        private int _column;
        private List<int> _listElements;

        public Matrix()
        {
            _row = 0;
            _column = 0;
            _listElements = new List<int>();
        }
        public int Row { get => _row; set => _row = value; }
        public int Column { get => _column; set => _column = value; }

        public List<int> ListElements { get => _listElements; set => _listElements = value; }
        public Dictionary<int,int> GetElementsBetweenIndexes(int a, int b)
        {
            Dictionary<int, int> _elements = new Dictionary<int, int>();
            for (int i = a; i < b; i++)
                _elements.Add(i, _listElements[i]);
            return _elements;
        }
        public string GetElementsToString()
        {
            string x = "";
            foreach (int el in ListElements)
                x += el + " ";
            return x;
        }
        public override string ToString()
        {
            return "Matrix: " + GetElementsToString();
        }
    }
}
